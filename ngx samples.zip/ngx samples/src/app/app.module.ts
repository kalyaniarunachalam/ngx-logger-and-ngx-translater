import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { AngularmaterialModule } from './angularmaterial/angularmaterial.module';
import {HttpClientModule} from '@angular/common/http';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { ChartsComponent } from './charts/charts.component';
import { PermissionsComponent } from './permissions/permissions.component';

import { NgxPermissionsModule } from 'ngx-permissions';


@NgModule({
  declarations: [
    AppComponent,
    ContactUsComponent,
    ChartsComponent,
    PermissionsComponent
  ],
  imports: [
    BrowserModule,
    AngularmaterialModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    ChartsModule,
    NgxPermissionsModule.forChild({
      permissionsIsolate: true,
      rolesIsolate: true})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
