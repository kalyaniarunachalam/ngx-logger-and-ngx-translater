import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.css']
})
export class ChartsComponent implements OnInit {
  chartOptions = {
    responsive: true
  };
  barchartData = [
    { data: [2, 10, 20,  8,  20, 100, 20, 20], label: 'Account A' },
  ];

  barchartLabels = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];

  onChartClick(event) {
    console.log(event);
  }
  // tslint:disable-next-line:member-ordering
  private barChartColors: any[] = [{ backgroundColor: ['#6b8d03', '#6b8d03', '#6b8d03', '#6b8d03' , '#6b8d03', '#6b8d03', '#6b8d03', '#6b8d03'] }];
  private barChartColors2: any[] = [{ backgroundColor: ['#e0f331', '#e0f331', '#e0f331', '#e0f331' , '#e0f331', '#e0f331', '#e0f331', '#e0f331'] }];
  private barChartColors1: any[] = [{ backgroundColor: ['#b843a5', '#b843a5', '#b843a5', '#b843a5' , '#b843a5', '#b843a5', '#b843a5', '#b843a5'] }];
  barchartData2 = [
    { data: [2, 10, 20,  8,  20, 100, 20, 20], label: 'Account A' },
  ];

  barchartLabels2 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  barchartData1 = [
    { data: [2, 10, 20,  8,  20, 100, 20, 20], label: 'Account A' },
  ];

  barchartLabels1 = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];


  // , '#00d9f9', '#a4c73c', '#a4add3'
  newDataPoint(dataArr = [100, 100, 100], label) {

    this.chartData.forEach((dataset, index) => {
      this.chartData[index] = Object.assign({}, this.chartData[index], {
        data: [...this.chartData[index].data, dataArr[index]]
      });
    });
    this.chartLabels = [...this.chartLabels, label];
  }
  constructor() { }

  ngOnInit() {
  }

}
